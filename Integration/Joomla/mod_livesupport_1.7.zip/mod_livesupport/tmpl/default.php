<?php // no direct access
defined('_JEXEC') or die('Restricted access');
?>

<div class="mod_livesupport"><?php echo $live_support_button ?></div>

